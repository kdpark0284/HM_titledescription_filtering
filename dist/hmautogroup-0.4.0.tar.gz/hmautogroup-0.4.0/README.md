# Clean & Group Titles for HM

Coded for Colab

# Installation

1. Open Colab and load Startup_Dependency.ipynb Jupyter Notebook
   This is the set up to use this library
2. Install the library
   {pip install HMautogroup}
3. Use main function


This project is licensed under the terms of the MIT license.
