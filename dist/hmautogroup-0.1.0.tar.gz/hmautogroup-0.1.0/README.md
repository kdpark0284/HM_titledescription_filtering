# Clean & Group Titles for HM

Coded for Colab

# Installation

1. Open Colab and load Startup_Dependency.ipynb Jupyter Notebook
   This is the set up to use this library
2. Install dependencies using requirements.txt
3. use HMautogroup_pre as the name of package
4. use main.py module
5. good luck



This project is licensed under the terms of the MIT license.
